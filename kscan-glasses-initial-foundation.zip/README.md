# K Scan AI Glasses Foundation

Pure HTML/CSS/JS foundation for the K Scan AI web app targeting Meta Ray-Ban Display glasses.

## What is included

- 600×600 fixed viewport.
- Pure black additive-display background.
- Luminous AR / Obsidian & Chrome visual system.
- Home, Processing, Results, Library, and Settings views.
- D-pad navigation through `ArrowUp`, `ArrowDown`, `ArrowLeft`, `ArrowRight`, and `Enter`.
- Visible-only `.focusable` focus manager.
- Mock scan flow only: Home → Processing → Results.
- No camera, face blur, backend, Supabase, or voice integration yet.

## Run locally

```bash
npm start
```

Open `http://localhost:5173` and set the browser viewport to exactly 600×600.

## Validate

```bash
npm test
```

## Notes for next phase

Replace the mock `startScan()` flow in `app.js` with:

1. DAT bridge photo capture.
2. Browser-side face blur/privacy sanitizer.
3. `POST /api/analyze` call.
4. Dynamic result rendering.
5. Supabase auth and library sync.

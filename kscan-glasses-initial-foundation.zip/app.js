(() => {
  const DPAD = Object.freeze({
    UP: 'ArrowUp',
    DOWN: 'ArrowDown',
    LEFT: 'ArrowLeft',
    RIGHT: 'ArrowRight',
    SELECT: 'Enter',
    BACK: 'Escape',
  });

  const FOCUSABLE_SELECTOR = '.focusable:not([disabled])';
  const VIEW_SELECTOR = '.view';

  const state = {
    currentViewId: 'view-home',
    focusables: [],
    focusIndex: 0,
    processingTimer: null,
  };

  function getCurrentView() {
    return document.getElementById(state.currentViewId);
  }

  function getVisibleFocusables() {
    const view = getCurrentView();
    if (!view) return [];

    return Array.from(view.querySelectorAll(FOCUSABLE_SELECTOR)).filter((element) => {
      return !element.closest('.hidden') && !element.hidden;
    });
  }

  function clearFocusClasses() {
    document.querySelectorAll('.focused, .is-focused').forEach((element) => {
      element.classList.remove('focused', 'is-focused');
    });
  }

  function renderFocus() {
    clearFocusClasses();

    if (state.focusables.length === 0) return;

    if (state.focusIndex < 0) {
      state.focusIndex = state.focusables.length - 1;
    }

    if (state.focusIndex >= state.focusables.length) {
      state.focusIndex = 0;
    }

    const activeElement = state.focusables[state.focusIndex];
    activeElement.classList.add('focused', 'is-focused');
    activeElement.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'auto' });
  }

  function refreshFocus({ preserveCurrent = false } = {}) {
    const previous = state.focusables[state.focusIndex];
    state.focusables = getVisibleFocusables();

    if (preserveCurrent && previous) {
      const preservedIndex = state.focusables.indexOf(previous);
      state.focusIndex = preservedIndex >= 0 ? preservedIndex : 0;
    } else {
      state.focusIndex = 0;
    }

    renderFocus();
  }

  function cancelProcessingTimer() {
    if (state.processingTimer) {
      clearTimeout(state.processingTimer);
      state.processingTimer = null;
    }
  }

  function showView(viewId) {
    const nextView = document.getElementById(viewId);
    if (!nextView) return;

    if (state.currentViewId === 'view-processing' && viewId !== 'view-processing') {
      cancelProcessingTimer();
    }

    document.querySelectorAll(VIEW_SELECTOR).forEach((view) => {
      const isActive = view.id === viewId;
      view.classList.toggle('hidden', !isActive);
      view.setAttribute('aria-hidden', String(!isActive));
    });

    state.currentViewId = viewId;
    refreshFocus();
  }

  function goBack() {
    if (state.currentViewId === 'view-home') return;

    const view = getCurrentView();
    const backTarget = view?.querySelector('[data-back]')?.getAttribute('data-back') || 'view-home';
    showView(backTarget);
  }

  function activateFocusedElement() {
    const activeElement = state.focusables[state.focusIndex];
    if (!activeElement) return;

    activeElement.click();
  }

  function moveFocus(delta) {
    if (state.focusables.length === 0) return;

    state.focusIndex += delta;
    renderFocus();
  }

  function startScan({ mock = true } = {}) {
    // This is intentionally a placeholder flow. Replace this later with:
    // DAT capture -> on-device face blur -> backend /api/analyze -> render results.
    showView('view-processing');

    if (!mock) return;

    state.processingTimer = setTimeout(() => {
      state.processingTimer = null;
      showView('view-results');
    }, 1200);
  }

  function handleKeyDown(event) {
    const handledKeys = new Set([DPAD.UP, DPAD.DOWN, DPAD.LEFT, DPAD.RIGHT, DPAD.SELECT, DPAD.BACK]);
    if (!handledKeys.has(event.key)) return;

    switch (event.key) {
      case DPAD.UP:
        moveFocus(-1);
        break;
      case DPAD.DOWN:
        moveFocus(1);
        break;
      case DPAD.RIGHT:
      case DPAD.SELECT:
        activateFocusedElement();
        break;
      case DPAD.LEFT:
      case DPAD.BACK:
        goBack();
        break;
      default:
        return;
    }

    event.preventDefault();
  }

  function handleClick(event) {
    const viewTargetButton = event.target.closest('[data-view-target]');
    if (viewTargetButton) {
      showView(viewTargetButton.getAttribute('data-view-target'));
      return;
    }

    const backButton = event.target.closest('[data-back]');
    if (backButton) {
      showView(backButton.getAttribute('data-back'));
      return;
    }

    const scanButton = event.target.closest('[data-action="scan"]');
    if (scanButton) {
      startScan({ mock: true });
    }
  }

  function init() {
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('click', handleClick);
    showView(state.currentViewId);
  }

  window.KScanApp = Object.freeze({
    showView,
    goBack,
    startScan,
    refreshFocus,
    getState: () => ({
      currentViewId: state.currentViewId,
      focusIndex: state.focusIndex,
      focusableCount: state.focusables.length,
      hasProcessingTimer: Boolean(state.processingTimer),
    }),
  });

  window.addEventListener('DOMContentLoaded', init);
})();

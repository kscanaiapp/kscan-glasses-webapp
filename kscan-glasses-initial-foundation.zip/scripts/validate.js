const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const files = {
  html: fs.readFileSync(path.join(root, 'index.html'), 'utf8'),
  css: fs.readFileSync(path.join(root, 'style.css'), 'utf8'),
  js: fs.readFileSync(path.join(root, 'app.js'), 'utf8'),
};

const checks = [
  ['viewport is exactly 600x600', files.html.includes('<meta name="viewport" content="width=600,height=600">')],
  ['all required views exist', ['view-home', 'view-processing', 'view-results', 'view-library', 'view-settings'].every((id) => files.html.includes(`id="${id}"`))],
  ['uses focusable class', files.html.includes('class="focusable') || files.html.includes(' focusable ')],
  ['body locks 600px width', /body\s*\{[\s\S]*width:\s*600px/.test(files.css) || /html,\s*\nbody\s*\{[\s\S]*width:\s*600px/.test(files.css)],
  ['body locks 600px height', /body\s*\{[\s\S]*height:\s*600px/.test(files.css) || /html,\s*\nbody\s*\{[\s\S]*height:\s*600px/.test(files.css)],
  ['true black background', files.css.includes('background: #000') || files.css.includes('#000000')],
  ['body overflow hidden', files.css.includes('overflow: hidden')],
  ['focus glow is cyan', files.css.includes('box-shadow') && files.css.includes('#00E5FF')],
  ['scrollbars are hidden for lists', files.css.includes('::-webkit-scrollbar') && files.css.includes('display: none')],
  ['D-pad key handling exists', ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Enter'].every((key) => files.js.includes(key))],
  ['focus list is view scoped', files.js.includes('getVisibleFocusables') && files.js.includes('getCurrentView')],
  ['no external runtime dependencies', !/<script\s+[^>]*src=["']https?:/i.test(files.html) && !/<link\s+[^>]*href=["']https?:/i.test(files.html)],
];

const failures = checks.filter(([, passed]) => !passed);

for (const [label, passed] of checks) {
  console.log(`${passed ? '✓' : '✗'} ${label}`);
}

if (failures.length) {
  process.exitCode = 1;
}
